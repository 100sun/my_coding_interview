#include "SparsePoly.h"

SparsePoly::SparsePoly() {
	nTerms = 0;
}

void SparsePoly::read()
{
	printf("Enter a degree maximum of polynomial : ");
	scanf("%d", &nTerms);
	for (int i = 0; i < nTerms; i++) {
		struct Term temp;
		printf("   Enter the Coefficient and Exponent of %d term : ", i + 1);
		scanf("%ld", temp.coeff);
		scanf("%ld", temp.expon);
		term[i] = temp;
	}
}

void SparsePoly::display(const char * str)
{
	printf("\t%s", str); // string parameter print
	for (int i = 0; i < nTerms; i++)
		printf("%d(x^%d)+", term[i].coeff, term[i].expon);
	printf("%d(x^%d)", term[nTerms].coeff, term[nTerms].expon);
}

void SparsePoly::add(SparsePoly a, SparsePoly b)
{
	int aCount, bCount, k;
	aCount = bCount = k = 0;
	// c = a + b : c = a, c += b;
	*this = a;
	nTerms += b.nTerms;
	// new temporary
	struct Term addP;
	// original a copy
	Term *temp = new Term[a.nTerms];
	for (int i = 0; i < a.nTerms; i++)
		temp[i] = a.term[i];
	// add
	while (aCount < nTerms && bCount < b.nTerms)
	{
		if (temp[aCount].expon == b.term[bCount].expon)
		{
			addP.coeff = temp[aCount].coeff + b.term[bCount].coeff;
			addP.expon = temp[aCount].expon;
			term[k++] = addP;
			aCount++;
			bCount++;
			nTerms--;
		}
		else if (temp[aCount].expon > b.term[bCount].expon) // a > b
		{
			term[k++] = temp[aCount];
			aCount++;
		}
		else // a expon < b expon 
		{
			term[k++] = b.term[bCount];
			bCount++;
		}
	}

	for (; aCount < nTerms; aCount++)
		term[k++] = temp[aCount];

	for (; bCount < b.nTerms; bCount++)
		term[k++] = b.term[bCount];

	delete[]temp;

}